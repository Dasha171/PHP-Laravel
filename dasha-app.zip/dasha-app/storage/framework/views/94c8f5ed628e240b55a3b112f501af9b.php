<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="/plugins/fontawesome-free/css/all.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="/css/adminlte.min.css">
</head>

<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">

        <!-- Preloader -->
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__wobble" src="/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
        </div>

        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-dark">
            <!-- Left navbar links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
            </ul>
            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <!-- Navbar Search -->

                <!-- Messages Dropdown Menu -->

                <!-- Notifications Dropdown Menu -->
                <li class="nav-item">
                    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <!-- Brand Logo -->
            <a href="/admin" class="brand-link">
                <img src="/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
                <span class="brand-text font-weight-light">KinoDasha</span>
            </a>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar user panel (optional) -->
                <div class="user-panel mt-3 pb-3 mb-3 d-flex">
                    <div class="image">
                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgVFhUYGBgaGBgaGBgYGBgYGhgaGBoZGRgYGBgcIS4lHB4rHxgYJzgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHzQrJCs0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIASwAqAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAECAwUGB//EADYQAAEDAgMFBwMEAgMBAQAAAAEAAhEDIQQxQQUSUWFxIoGRobHB8AbR4RMyQmJS8RQjkoJy/8QAGQEAAwEBAQAAAAAAAAAAAAAAAgMEAQAF/8QAKBEAAgICAgICAQMFAAAAAAAAAAECEQMhEjEEQSJRgTKR8BMzcaGx/9oADAMBAAIRAxEAPwDzohQLQrFFVHm2VOpBQdQRCZaEpMEcwhW0Kk5qwhCnslcGvkqClF2SeUzskQCK6SsVdLJWLEbLsYqDFY0KNQgLTl9CSTB4TyuNoZOkQmXezCaSiktZwxSSKSBmiKSZJYaFpJJitEjJJJitNGVOIbIVyi5aFF07KqDpEKbslBtJwMgSNY0RlXDhrZc6JyEXPfogc1FbGcW3oEpZKasbUpsiWujjOfiEVhqlBxuC0cYJQf1YpGvHKwN1gqHCVvnZAe2abw7kJ3v/ACfZZFfDuYd1zSDzRxlGXTA4uPYIWJbpVxSIR0FyKd8hWMdKRaoMsYXHaaLUkgmWsARTJymQMISSZJYcGlRIQorngpDEcltA8WXlRVYrhOKoXUZT+iRKHfieGXH7KnE194wMvVD7yVKTekU48aW2dDsrb36IMMY4kR2hPjx6LoNhY5lVw/U3RMloDG3GRgZAeJsvP5RmG2g5lxnEDlqfdIlG+hyo3fqHZTf1C+lO44m5I3d4yYaNBDXLnGvIMEkXjvWydoOeKTCZlznE83N3fee9CYrdqS+1z2otBgXA537+qyP0zNotwGIewgg/fqOK67CYqniW7ldku0cOy8cCCcyuKwtMtMCHZ9g/ytPZ4Oi44rfwDmPa2Z/q4GHNPA9+qCWto3T0WbR+lXsG/TcKjPBw6hc9UYWmCIXouz8W5lnSchvtuY/uPnso7X2Ays0uZAcRIj9rjxHNNx+V6l+4qWH2jzpU1RqjcZhX03ljxBCHeFdprROtMTCkVVSOitWHNUxiop3KLihZqGcUk7WpLQgktUSwK0pitEJlJpBC4ogWCOcYErJqPkkpc5UqKMSbdsZJJIpJSJJJJYcH7Ld228vnuqcFUg7pyIj0IPlKfAOh4+c/ZV1mbrunsSPZZWzrCHPMwLWtyLTLY5iIWrgK29DhaTDm/wBs5HjPesZxgg9PP8gonCVN15jJwkcjmD3XWShcTk9nabJxBktJ7Qjd5iMueS3MNW3e0AS0ntNOhJ04FcRRx+7uvzLTDuhuD4nz5LqsLimQHyN13ZeOEgQY8lFOEkx8aYR9Q7JbiGbzY3h+12p/qV5xVpkEtcIIsvQ9nY7ceWEy3ejoTkehjxBWZ9UbJ3pewdrO38hwPPUHqqvGz0+MuifPhv5R7OGcIKsKlUzNtSDyKYr0F0SMrcVBo1U3FQ3whNXRYkofqBJcdTDExTlRJRCUC46pbd4oIqeIfLiVBTSdsuxx4xQkikkVgYk6ZPC6jiyjmr8Y2YdxHmDdU0gjHiRHG4R8QLBxdo5GO5O0+SRaRb5yT0mSVqVHF1B/8TkbHof9z3IrAbQcwgO0lrxxB16i6pbRtKrczM8wlyhfYUZbNtmPIe0EzPZnv7J/9bp7l1WBxe/TE6Lzp9QgN6A9CNfD0XU/TmJkFs8/H8x4lS5IcVZRF8tGbtvCBry9ojiBpz6LIJkSt/bL917gRHTnn3SsKoBoIB04K/DK4I8/LGpMoaZTupDNQcIuraVRMBdraK9xOrXCEl1HWy4hV1TAKj/yFVWrS0rGtAxi7AkikEipy0QTpgnXIxiVzmGJTU2SQjXtG7CYloBvYJhxdHBsx1sg2MOiKZhHgTIHUo4xbQE5JPbLTQU8PhtUqDX6EHvC0qDTF806GNMmy55R6Kf0RCz8Q7+LRfjotWsYaTpksDGOdoCG8guyUlVA4OUnbYzqcD90laOwsVu1M/lvsscNIjmFZgau68Hmo8kVJdHpYm4tbOt+oGSAYkdbjoVzbjaF1m0Gb9EOb3fPma5N/nqu8Z/GgPJVTv7KSFDJWFRIVDEIupumySHBgpLrBcQosCpxDQGlElC4t1lkujIW5ICSKScKdFo7GqTGSVIC0cVdhm2JTFEGx2NAKKLJHmgqTpMrQa6yNUKlZS54bfwVNcVCASDDrgIl1HeV9PCyIJMcNEyMG9Cp5IxdgeCaWgOM3JEZ960xiNFBtDdVYpo3FwjoRJxyStm5s7C/r0qjB+8Q5g/yjNveueq03ftMxwOnJaeycYaT2vByPiF1v1BshlVgxNMWcAXxo46pUp0/l0/+joRTVR7R5+3ChBVKO68c10rsA4XAkLG2oO20dfZLnXopx3WzosDXP/GcP8XN6xP4XO4ynuuMXEm45Z/Oa6LZjJoPB1AI7jK57GtIdf8AB/P2SvHe2H5K2gMpJFJVExB4SUinQm2EuKAxLrwi6rlnvzKHJLVHYY7sipMTKzDjteaVFbKGWuEDn6BOw9h3z5movyT4QyCOKb7BKqZR9IrPiCjsM5YgWHsCJYUOwq9oVWORDnj7JbsqnEjdHVFtahsSb9EzIviJxS+SKcPQJuSu1+mtrOYf0ju7rmkGco6LigXPcLnQBswF2f0thWN3nVS1rwd0bzmj/wAypcjSxtNFuKEpZU0wLB15JbpJhYm0MOHYxjdDY99l1W2cIym/ebabrm8GP1MSD17gAQPVTTa4uS+i2CdqL+zXweH3GQ7IvDe66x9vbIfTJ1bmx2hGbmnmM/FdbtXDTQJbm17SfEtPk4K1pY5v6VQSx4EO/wAXDnpyKkhmcZWPy41NHlJCS2tv7EfQe5uYF2n/ACaeXz2WGvThNSVo85xadMRSTOSXHF1VAHNaLo1QDrk8EvIgsTIuCsoZqslWMEQhXY1knmyVExBTOMqTh2QmJewWx8VofkqeGcqmuBEHuT0DBhc+7M9UbFIoymgKLkWxydDTJM21QYEPiGgCSrWLK2uxziINgMvdPnKo2SYYcp1YPUqF5O6bDWYH5VdVzgBDnHpKpa0g5QjKGILSCGzHG4U7blE9eEeLVOkF4bHVy1oeXbsdjezjlyUtmYjcrNfOsHocj6qNXFPqRvmSAGgf4jQDxKqoMlxA0seuvmfJSZHUVFjoxubkj1GjuvbB/ZUYWuHB2o91E4UbppuzbbqOP56LF+mtpgsDH5WB5OGThyt5Lo8bJa17SJb4Eag93ovOnFoqTMfG4X9ai6m69SmN6mZhxA0niV5viWfyGpvpc5EcJg20IK9Qc/de14HA/wDy7Pw9iuA+ocOGVarW5b5dHDeJIjkZPSIVXiT7iTeTCvkYbkk7imVxIKpULrDJVvbAgK8NAHy6hVFggcX2w00tIqpsT1eCtbbuVeZlFSSo67Y7GeanWPkrqbIBJz05BCTJ70xrjGvsFPk/8EXi3QkJ2FXPp9gnn+EOw3SmqaDu0aeGq6LQY6Vk0wiqTyE2LJZo02vUHsVLKhVgqcU27VMlpxdoTKGgTVsPAsp/85rc3BA4nbDf4gnyC5yhFBxWaUrolWIYC/UCw4u08/RNsWnvNib3P3WVXrueZd3DQI/ZLy3uM9xXn5vldHr4bVJm3gnlp3hr+8aj+45jULqsBtExJuP2vHDgehzBXIViZ3hrfvReBxpBDjkRuv8Av84JLjyjY+Lp16OvDQQBNt6Af6n7LgPqCp/21RrvXnoAe7srq8PirbvAi/oVwu16u9We7+xj/wBflD4samzPKdRSAnN4eGv5STc0y9Gjz9juCg0y4JVH5qtnFLlLdBxjq2WVHaKVBupUK32RDBkEcf1GP9JYZLT81Q2EpEmVo4OlJLTwUMO2HZftnyVHG6kxHOk0hsQyGnlDR6lZRF1sYo2a3q49Tksp4ul54jML0E0EWxBYd4yRzCshtC8mmXMKjWqWSBQ+IcjbpCYxuQBiHSVUxqlUUqYsSpWrkejHSGi6Mw79xwOkX6INuaIf7LKtBJ0zYNS0TbMdCp4F3ag6iFkUK1o8PdaGDffx9Epx0x8ZW0a+Gqm17wW+GXqubxb5c4kDPPrx8CtvDPgF3A/ZYONEPcOZR4V8mL8h6QMbpKSSqJLKIU25d8fPJReMlKbN6n2HskoaWNExyhSou8ioss75qnHZddFH7BkvRqtMOa4aj8FNimw8kZOAPjn6KFASwt4GR7j5wT4h0tadQd37KxO41+SOqf8Aoi5sy7hI8Pyg6tPeEjMZ9Fq4gblIN8e78rMpkg/O8LckV0w8bdWvwCMsjqbtVU6kAY0NweStw7AD6JEYtOhk2mrLg5DV3ItzcwgsSICKSpCoU2BPN1a39qpdmrWOso/bLUJgurK/29FCmrKjZB7l3oL2NQzC0MM7NC0qR8fRamEpAAzw8s/ZZJVEZDs6j6b2aH0nlw/cIHLWfEDwK4jaTO28/wBjK9B+lcUC3dOp9tPFcNtlv/ZUI/zcSI6pPjzbm7C8qNRVGYknLh0SVxCVPFx0T1G9lv8A9eqIxFC1uo+ygwS0jUGfGx9kPFptBKaaTKhccwrH9psqoWv85q9ljGjsvb7LIr0a37L8FW46WPRXzfd5g94sPULPp2f5HvRxN5+fJKbjbsCaVFmMlwAHwBDMzvy/KLp1w18HKw8b38VLaWHDbtyIkeOSrau5ImUuNRfsFfS7J/qfI/PNQpgixReHuRzBHl+FbTo2jP5og427RznWmCOchcU6yPrUo6dPVAYtg0tyS8l0w8bTaAykrAyVAadVK4laZOIICMo07z5KuBM66cgNVfvhoHE+Q/KNRUezLb6LxDRJzT1K+6ydXeijs6i6o503y8/tHklj29trdAT3RA9knM+VL0U41xVnT/SQO8CL7s+8JvrDYwO7XYLGGvH9hr0I9EX9IUv3nlHuugfQ36b2HUHuIyPiF58Z8cloflXKFHjtSmA4gG026aJI/HYUtcRAsTEfbxSXqxao8x2PWp3jj8lDbsOvn6g5960iySg8e2wPNOlGtkuOdugOrTgkeHMf6VbDbd7x9kU3tN/sMuY4IR4vbglyVbRVF3plouQdZEolxuBz+/2QuGPajmEZVZBaeJ/H3RQV7Bm0nRVi2kOniQjaNUvZuk9OQyPnPgrMbQ3mDuvwI1QTTAnSYHS35VG4yf0ITU4r7RbhzAHVaLmW3mlCNpw1vQHyv6owHclrjFyOWuvP3Wwl6YvOtpoi7tCNQsvGUYuOi1XNGYuqcewZ6ff8opxtbAxS4y0Ym7dVNbdFuYbj58shw2/n4T91FKNHoRlZM9otjI2801WS484hLCuzb4dVtfTeyv13uc6zGNLnHgYMAc5Spuo2OgrlR0X05gmmkx0XdT3zbLde5p9UPt7YZa8VG3aSARoDr3ER4LodhU27242wbTbTHQgv3ud7Keynb7XMfrLOjm9e9QuclZeoqkgTYFLda14Mhx7XLqt0WniCfuD5rmMBX/RruY4Q0ndI0BMju/aumL/2nr3gjP0UktSCe0cF9WYRu9+o2xsSB526+qZEfVTC2xyEjzsfVJerglcEebljUjHDrqjHtsekqyra6DxlSQvQnKk0ebjVyTB8PIAPMqupcyOfjkfnNSe6B0HqoMyPcfEX9El9JFiW+RLBi8/LI+u6zf8A8z5knyKzaTonvWhi2yGxmAPniEcGooGcXKSDqVYPYRqR5j7iPBZ1GlvPa3if9+6hvlm68ZHPktPZ4BeX8vW5RRnzkkxc4f0ouS/jCq9K9hbkhNoEljoBA3hfPWwOi0HQ61+NvltUtoNmi4NaYAvvHtSCCT5J81dkOObTSf2cuKjmmWki1x05aoirtE3aQCNDlbMHzVbm3ETy3YMTlPEzCl+m1wbP7iSOAdugQORupvkrSZ6TUXtomKk7p4ie4GPZC4ioN6wiCpV7QP8AG3S8+6qrGbrJu4tGwik7KxnbjZdns/FChhnCLudLiOQHZ8wuVwTJfOg1+y2doP3Wsb/J0k8hED18kMcacW36NeVqaivZ1X09tBpLH6jsu5g3aT3z4rUq0Cyu8gGD2uRIg26rzrYWKLSW6i45gZj5wXo7MaKjGOGdgfC3p5FRTw6TX5PRhlt7Mf6yp7r2Vm5PHa6wPx3hFbOxkMBdpeDq0/D4J9vguott5eh6ei5/DYjsuHLXr+Uqfj3G/o5ZUpcTofqPBNr0i9hkgEkcQbwPNMs5+Pc1rC3+dN2X+dP9xjmEknHOUVQMoRbs5nElZzs0biCgnr28nZ4+JaB6psQlhzb58/2mqi6lVbuxGiTu7K01pEXHdPfKMoVd5sHMD2VOKpgta4aqzAsnvlE07o7kqv8ABc9n/XJ4onZzS0GeX3TYhn7GDhJ+dynXfDTHP0hPUVFp/RM8jlFr7J7OxkvIJscjw4LUxDZaQYnddc5OAmy5TDvhw62XZUsQ19OHNIdBk7pi4EOB+ZooTbTJfIx8ZKS6OTe0EWMgCwFgI4nUqvQgyNRra8gHvCtDrxciTMiGjUzzuqXtgeF2n1CB7LV9FVSpo4dOI7/ZJtFpbIdJLo3eAiZVTx3cs/FSpmxHKfDNJbt7G1S0HbPaC9jRlMk8SFZiqhfWn+0DoFVsZ3anhPz0U6TYqxw906O4perEypSb9pA+FfuVJGjiO45rsNhYwXYSY7Xldp81x9Rl3nmfVaeFxBZTLv5ugAaxr7JCXyKuVROk2ntEiWCHNNom0AeRWCaoAJGoKCp4suseiIZa+nBDJqjld2aDdoM/SbJ7dN7iBxa9sHzSXOY+Q62X30SULwqx3MMqBB1kY82QVVerk6PMxlRzClWyPX56KANwnDkqL0PLMLUlrmHq3qNFfg3xbgs9joIPNaAtJGsEfOqODv8ABmRV+QlsmoTyj3VWKdI7k2Gqdre4J8Tct6EeKa38WISqSAGZ/NF2WBrO3BLZHI3+fZctQpXNsrLqsO4NYATBAEEiRlxy1QYl2K82V0kctWB3jY2M9o2F4B55BRqOm0zfURnz+ZqWLeP1XQAYc65JLRfMDvVL3zNyZ4i2Qy4LmypLSB3D4Pcq3BYgsdIANnNgjRwIPqqnHp3ZJm1CMvJKbp2hvqjQ2dTLXDw+eSPxGEIfvGL5cT3IBhlxAPEi8xkb9FpDFy1pNyIB/PFPtKNInafNP9wPEUxvOGQkyeKCxNUlwiwGSMqPlxni4e491SKIce6fBC4fHQ3nvZWzii2VSQQLFVMaPBU78Oj5dKlG1YyM90V4h05/OSSbEu8dUkkMNLpQlREMNiqHi6ok7RJHTKgFBxVhUXBLHop0RuGfIjwQblZRdC6MqZslyQThyQ4DQm/ejMSyQICEoum6MY6QAeifGqolyWmmGYSlJDuOfUf6W4yHNIa4GwtbQ+qydnkT2gS2bgWmMhPzNdJSwjXsqu3GMaymH06jT+79ohwGp3iL3kdQm6SIclybZ5/tygW1S4CASDmDoEK2pvSbzqZ66cFrbdZFQEgSW5uEARYWGZhYdVu660xztI6aJEtO10ephfLGr7od3y3yVAqc/PsoFLY1GhhiJEHNvgTmERhqgvP8Ztx5+KE/5Ld1ga3dc0EOdM7xJmYi1oEck2Jqw+RkbxxnNN5JR2KcLZa7Pnn1SoV9108D5FJ2QIyVb2yCYm1yEV/QKSemWvbukjqhcSe0iKdSQCYJyvmhsS69uCVOuOg4Xy2RqulJUykp7KKNNqg8K0KFRUPohT2UuCiQrSoIaGp6KXBME5Um5oWNiTorQomyCpao3DZFNxsRnXsPwkz3f7W1Sxzt0MLnbgkhgyk6wMysHDad606InUiZuLFUx2jzMvZj/UNUbzHEhwgtMZiCCD1CxK159Zmea2PqWkAGEZkmfBZdMf8AUTq0gDoTqp5v5NHp+P8A2ov+dg7Mkj8umYk9KvRR7H3k9R0gKtqk5ZemdWwrDVf46JVXxbj4FDUc1YXmCNExSuIDj8iyk7smyHqOlWYc9k/NFS5Lm7igoqmxUGbzgOJSU6Bh1kkqmMtH/9k=" class="img-circle elevation-2" alt="User Image">
                    </div>
                    <div class="info">
                        <a href="#" class="d-block"><?php echo e(auth('admin')->user()->username); ?></a>
                    </div>
                    <div class="info">
                        <a href="<?php echo e(route('logout')); ?>" class="d-block">Logout</a>
                    </div>
                </div>

                <!-- SidebarSearch Form -->

                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

                        <li class="nav-header">EXAMPLES</li>
                        <li class="nav-item">
                            <a href="/admin/categories" class="nav-link">
                                <p>
                                    Категории
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/admin/countries" class="nav-link">
                                <p>
                                    Страны
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/admin/films" class="nav-link">
                                <p>
                                    Фильмы
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/admin/category_films" class="nav-link">
                                <p>
                                    Жанры
                                </p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="/admin/users" class="nav-link">
                                <p>
                                    Пользователи
                                </p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><?php echo $__env->yieldContent('title'); ?></h1>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                </div><!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div><!--/. container-fluid -->
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->

        <!-- Main Footer -->
        <footer class="main-footer">
            <strong>Copyright &copy; 2023 <a href="/">Kinotower</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 1.1.1
            </div>
        </footer>
    </div>
    <!-- ./wrapper -->

    <!-- REQUIRED SCRIPTS -->
    <!-- jQuery -->
    <script src="/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- overlayScrollbars -->
    <script src="/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
    <!-- AdminLTE App -->
    <script src="/js/adminlte.js"></script>

    <!-- PAGE PLUGINS -->
    <!-- jQuery Mapael -->
    <script src="/plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
    <script src="/plugins/raphael/raphael.min.js"></script>
    <script src="/plugins/jquery-mapael/jquery.mapael.min.js"></script>
    <script src="/plugins/jquery-mapael/maps/usa_states.min.js"></script>
    <!-- ChartJS -->
    <script src="/plugins/chart.js/Chart.min.js"></script>

</body>

</html>
<?php /**PATH C:\OpenServer\domains\dasha-app\resources\views/layout/admin.blade.php ENDPATH**/ ?>