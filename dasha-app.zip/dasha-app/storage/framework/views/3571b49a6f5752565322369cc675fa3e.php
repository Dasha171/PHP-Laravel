<?php $__env->startSection('title', 'Список пользователей'); ?>;

<?php $__env->startSection('content'); ?>
    <div class="row mt-4">
        <div class="col">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>№</th>
                    <th>ФИО</th>
                    <th>День рождения</th>
                    <th>Пол</th>
                    <th>Почта</th>
                    <th class="w-25">Удалить</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($user->fio); ?></a></td>
                        <td><?php echo e($user->birthday); ?></td>
                        <td><?php echo e($user->gender->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-block btn-danger btn-flat">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\dasha-app\resources\views/admin/user/index.blade.php ENDPATH**/ ?>