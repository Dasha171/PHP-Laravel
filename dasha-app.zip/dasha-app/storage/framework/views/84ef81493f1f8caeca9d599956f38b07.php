<?php $__env->startSection('title', 'Главная страница'); ?>;

<?php $__env->startSection('content'); ?>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Libero, optio.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\laravel_kinotower\resources\views/admin/index.blade.php ENDPATH**/ ?>