<?php $__env->startSection('title', 'Список отзывов'); ?>;

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <a href="<?php echo e(route('reviews.create')); ?>" class="btn w-25 ml-auto btn-block btn-success  btn-flat">Добавить</a>
        </div>
    </div>
    <div class="row">
    </div>
    <div class="row mt-4">
        <div class="col">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card p-4">
                        <div class="row">
                            <p class="text-bold text-lg"><?php echo e($review->user->fio); ?></p>
                        </div>
                        <div class="row">
                            <p><?php echo e($review->created_at->format("d.m.Y")); ?>

                                в <?php echo e($review->created_at->format("H:i")); ?> </p>
                        </div>
                        <div class="row">
                            <p><?php echo e($review->message); ?></p>
                        </div>
                        <div class="row <?php echo e($review->is_approved ? 'text-success' : 'text-gray'); ?>">
                            <p><?php echo e($review->is_approved ? 'Подтвержден' : 'Ожидает проверки'); ?></p>
                        </div>
                        <div class="d-flex flex-row flex-grow-1 justify-content-end">
                            <div class="m-1">
                                <form action="<?php echo e(route('reviews.approved', $review->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit"
                                            class="btn btn-block btn-success btn-flat"><?php echo e($review->is_approved == 0 ? 'Подтвердить' : 'Отменить'); ?></button>
                                </form>
                            </div>
                            <div class="m-1">
                                <a href="<?php echo e(route('reviews.edit', $review->id)); ?>"><button type="submit" class="btn btn-block btn-primary btn-flat ">Редактировать</button></a>
                            </div>
                            <div class="m-1">
                                <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-block btn-danger btn-flat">Удалить</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\dasha-app\resources\views/admin/review/index.blade.php ENDPATH**/ ?>