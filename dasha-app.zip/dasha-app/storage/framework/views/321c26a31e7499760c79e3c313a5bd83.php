<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Films</title>
    <style>
        body{
            background-color: rgb(42, 42, 65);
            color:aliceblue;
        }
    </style>
</head>
<body>
   <p><?php

    ?></p>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\dasha-app\resources\views/film/film.blade.php ENDPATH**/ ?>