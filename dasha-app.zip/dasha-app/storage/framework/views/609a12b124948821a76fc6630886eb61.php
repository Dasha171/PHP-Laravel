<?php $__env->startSection('title', 'Список жанров фильмов'); ?>;

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <a href="<?php echo e(route('category_films.create')); ?>" class="btn w-25 ml-auto btn-block btn-success  btn-flat">Добавить</a>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Фильм</th>
                    <th>Жанры</th>
                    <th class="w-25">Удалить</th>
                </tr>
                </thead>
                <tr>
                <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($film->categories->isNotEmpty()): ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($film->name); ?></td>
                            <?php $__currentLoopData = $film->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!$loop->index+1 == 1): ?>
                                    <td></td>
                                    <td></td>
                                <?php endif; ?>
                                <td><?php echo e($category->name); ?></td>
                                <td>
                                    <form action="<?php echo e(route('category_films.destroy', $categories_films->where('category_id', $category->id)->first()->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-block btn-danger btn-flat">Удалить
                                        </button>
                                    </form>
                                </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\dasha-app\resources\views/admin/category_film/index.blade.php ENDPATH**/ ?>