<?php $__env->startSection('title', isset($category_film)?'Редактировать жанр: '.$category_film->name : 'Добавить жанр' ); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(isset($category_film) ? route('category_films.update', $category_film->id) : route('category_films.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($category_film)): ?>
                            <?php echo method_field("PATCH"); ?>
                        <?php endif; ?>
                        <div class="form-group">
                            <label for="category_id">Category id</label>
                            <select name="category_id" class="form-control">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="film_id">Film id</label>
                            <select name="film_id" class="form-control">
                                <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($film->id); ?>"><?php echo e($film->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary ">Добавить</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /srv/http/laravel_kinotower/resources/views/admin/category_film/create.blade.php ENDPATH**/ ?>