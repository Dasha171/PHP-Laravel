<?php $__env->startSection('title', 'Список оценок'); ?>;

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col">
            <a href="<?php echo e(route('ratings.create')); ?>" class="btn w-25 ml-auto btn-block btn-success  btn-flat">Добавить</a>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>№</th>
                    <th>Пользователь</th>
                    <th>Оценка</th>
                    <th class="w-25">Удалить</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index+1); ?></td>
                        <td><?php echo e($rating->user->fio); ?></td>
                        <td><?php echo e($rating->ball); ?></td>
                        <td>
                            <form action="<?php echo e(route('ratings.destroy', $rating->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-block btn-danger btn-flat">Удалить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /srv/http/laravel_kinotower/resources/views/admin/rating/index.blade.php ENDPATH**/ ?>