@extends('layout.admin')

@section('title', 'Список фильмов');

@section('content')
    <div class="row">
        <div class="col">
            <a href="{{route('films.create')}}" class="btn w-25 ml-auto btn-block btn-success  btn-flat">Добавить</a>
        </div>
    </div>
    <div class="container mt-4">
        <div class="row">
            @foreach($films as $film)
                <div class="col-sm-5">
                    <div class="card p-4">
                        <img src="{{$film->link_img}}" class="w-75 text-center h-50" alt="Тут должна быть картинка">
                        <p>Название: {{ $film->name }}</p>
                        <p>Страна: {{ $film->country->name }}</p>
                        <p>Длительность: {{ $film->duration }} мин.</p>
                        <p>Год: {{ $film->year_of_issue }}</p>
                        <p>Возраст: {{ $film->age }}+</p>
                        <a href="{{ $film->link_kinopoisk }}"><p>Кинопоиск</p></a>
                        <a href="{{$film->link_video}}"><p>Посмотреть трейлер</p></a>
                        <div class="d-flex flex-row flex-wrap justify-content-start">
                            <div class="m-2">
                                <a href="{{route('films.edit', $film->id)}}" class="btn btn-primary btn-flat">Редактировать</a>
                            </div>
                            <div class="m-2">
                                <a href="{{route('ratings.index', ["film_id" => $film->id])}}" class="btn btn-success btn-flat">Оценки</a>
                            </div>
                            <div class="m-2">
                                <a href="{{ route('reviews.index', ['film_id' => $film->id]) }}" class="btn btn-dark btn-flat">Отзывы</a>
                            </div>
                            <div class="m-2">
                                <a href="{{ route('category_films.create', ['film_id' => $film->id]) }}" class="btn btn-light btn-flat">Жанры</a>
                            </div>
                            <div class="m-2">
                                <form action="{{route('films.destroy', $film->id)}}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-flat">Удалить</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
@endsection
