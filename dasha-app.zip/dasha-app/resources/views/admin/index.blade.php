@extends('layout.admin')

@section('title', 'Главная страница');

@section('content')
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Libero, optio.</p>
@endsection