<?php

namespace App\Http\Controllers;

use App\Models\Film;
use Illuminate\Http\Request;
use App\Http\Requests\FilmRequest;

class FilmController extends Controller
{
    public function index()
    {
        $films = Film::all();

        // return response()->json($films);
        return view("films.index", compact("films"));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("admin.film.create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(FilmRequest $request)
    {
        $data = $request->validated();

        Film::create($data);

        return redirect(route('films.index'));
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Film $film)
    {
        return view('admin.film.create', compact("film"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(FilmRequest $request, Film $film)
    {
        $film->update($request->validated());

        return redirect(route('films.index'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Film $film)
    {
        $film->delete();

        return redirect(route('films.index'));
    }
}





    // public function index()
    // {

    //     $films = Film::all();
    //     return response()->json($films);
    // }




//вывод на с страницу
    // public function index(Request $request)
    // {
    //     $films = Film::all();
    //     return view('films.index', compact('films'));
    // }
//     public function show($id){
//         $film = Film::findOrFail($id);
//         return response()->json($film);
//     }
// }



//СОРТИРОВКА
//     public function index(Request $request)
// {
//     $query = Film::query();

//     // Фильтрация по названию фильма
//     if ($request->has('title')) {
//         $query->where('title', 'LIKE', '%'.$request->get('title').'%');
//     }

//     // Сортировка по дате выпуска фильма
//     if ($request->has('release_date')) {
//         $sortDirection = $request->has('sort') && $request->get('sort') === 'desc' ? 'desc' : 'asc';
//         $query->orderBy('release_date', $sortDirection);
//     }

//     // Пагинация списка фильмов
//     $films = $query->paginate(10);

//     return response()->json($films);
// }
